<?php
$html_1 = get_theme_mod( 'colormag_header_html_1', '' );
echo '<div class="cm-html-1">';
echo $html_1;
echo '</div>';
