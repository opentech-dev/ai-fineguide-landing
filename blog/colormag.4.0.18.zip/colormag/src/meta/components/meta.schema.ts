export enum PanelTypes {
	'GENERAL' = 'General',
}
