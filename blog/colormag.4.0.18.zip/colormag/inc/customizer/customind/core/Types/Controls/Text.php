<?php
/**
 * Text class.
 */

namespace Customind\Core\Types\Controls;

/**
 * Text control class.
 */
class Text extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-text';
}
