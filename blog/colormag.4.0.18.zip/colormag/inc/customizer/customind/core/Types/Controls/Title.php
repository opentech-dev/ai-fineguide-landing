<?php
/**
 * Toggle class.
 */

namespace Customind\Core\Types\Controls;

/**
 * Toggle class.
 */
class Title extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-title';
}
