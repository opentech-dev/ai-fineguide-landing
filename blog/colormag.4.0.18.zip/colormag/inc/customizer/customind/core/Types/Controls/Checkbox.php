<?php

namespace Customind\Core\Types\Controls;

class Checkbox extends AbstractControl {
	public $type = 'customind-checkbox';
}
