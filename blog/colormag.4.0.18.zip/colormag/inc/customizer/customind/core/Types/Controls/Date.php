<?php
/**
 * Date control class.
 */
namespace Customind\Core\Types\Controls;

/**
 * Date control class.
 */
class Date extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-date';
}
