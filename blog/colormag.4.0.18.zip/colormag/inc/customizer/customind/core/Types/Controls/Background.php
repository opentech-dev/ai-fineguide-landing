<?php

namespace Customind\Core\Types\Controls;

class Background extends AbstractControl {
	public $type = 'customind-background';
}
