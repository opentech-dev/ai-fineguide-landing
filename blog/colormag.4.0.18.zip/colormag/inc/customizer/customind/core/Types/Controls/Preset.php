<?php
/**
 * Preset control class.
 */
namespace Customind\Core\Types\Controls;

/**
 * Radio image control class.
 */
class Preset extends AbstractControl {
	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-preset';
}
