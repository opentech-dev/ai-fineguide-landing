<?php
/**
 * Editor control class.
 */

namespace Customind\Core\Types\Controls;

/**
 * Editor class.
 */
class Editor extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-editor';
}
